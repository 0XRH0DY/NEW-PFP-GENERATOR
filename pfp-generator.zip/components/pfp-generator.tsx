"use client"

import { useState, useRef, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Download, Shuffle, Check, X } from "lucide-react"

// Asset configuration - easily replaceable with your artwork
const ASSETS = {
  backgrounds: [
    { id: "bg-1", name: "Green", color: "#5a8f7b", type: "color" },
    { id: "bg-2", name: "White", color: "#ffffff", type: "color" },
    { id: "bg-3", name: "Cyan", color: "#4ecdc4", type: "color" },
    { id: "bg-4", name: "Pink", color: "#ff6b9d", type: "color" },
    { id: "bg-5", name: "Black", color: "#1a1a1a", type: "color" },
    { id: "bg-6", name: "Yellow", color: "#ffd93d", type: "color" },
    { id: "bg-7", name: "Cream", color: "#f5f5dc", type: "color" },
    { id: "bg-8", name: "Orange", color: "#ff8c42", type: "color" },
    { id: "bg-9", name: "Purple", color: "#9b59b6", type: "color" },
  ],
  clothes: [
    { id: "clothes-none", name: "None", image: null },
    { id: "clothes-1", name: "T-Shirt", image: "/simple-t-shirt-clothing-layer-transparent.jpg" },
    { id: "clothes-2", name: "Hoodie", image: "/hoodie-clothing-layer-transparent.jpg" },
    { id: "clothes-3", name: "Jacket", image: "/jacket-clothing-layer-transparent.jpg" },
  ],
  styles: [
    { id: "style-none", name: "None", image: null },
    { id: "style-1", name: "Cool", image: "/cool-sunglasses-style-layer-transparent.jpg" },
    { id: "style-2", name: "Nerd", image: "/nerd-glasses-style-layer-transparent.jpg" },
    { id: "style-3", name: "Smile", image: "/happy-smile-expression-layer-transparent.jpg" },
  ],
  accessories: [
    { id: "acc-none", name: "None", image: null },
    { id: "acc-1", name: "Cap", image: "/baseball-cap-accessory-layer-transparent.jpg" },
    { id: "acc-2", name: "Beanie", image: "/beanie-hat-accessory-layer-transparent.jpg" },
    { id: "acc-3", name: "Crown", image: "/crown-accessory-layer-transparent.jpg" },
  ],
}

export default function PFPGenerator() {
  const [selectedBackground, setSelectedBackground] = useState(ASSETS.backgrounds[0].id)
  const [selectedClothes, setSelectedClothes] = useState(ASSETS.clothes[0].id)
  const [selectedStyle, setSelectedStyle] = useState(ASSETS.styles[0].id)
  const [selectedAccessory, setSelectedAccessory] = useState(ASSETS.accessories[0].id)
  const [isOpen, setIsOpen] = useState(true)
  const [loadedImages, setLoadedImages] = useState<Record<string, HTMLImageElement>>({})

  const canvasRef = useRef<HTMLCanvasElement>(null)

  // Calculate total combinations
  const totalCombinations =
    ASSETS.backgrounds.length * ASSETS.clothes.length * ASSETS.styles.length * ASSETS.accessories.length

  const totalAssets =
    ASSETS.backgrounds.length + ASSETS.clothes.length + ASSETS.styles.length + ASSETS.accessories.length

  // Randomize all selections
  const randomizeAll = () => {
    setSelectedBackground(ASSETS.backgrounds[Math.floor(Math.random() * ASSETS.backgrounds.length)].id)
    setSelectedClothes(ASSETS.clothes[Math.floor(Math.random() * ASSETS.clothes.length)].id)
    setSelectedStyle(ASSETS.styles[Math.floor(Math.random() * ASSETS.styles.length)].id)
    setSelectedAccessory(ASSETS.accessories[Math.floor(Math.random() * ASSETS.accessories.length)].id)
  }

  useEffect(() => {
    const imagesToLoad: { id: string; src: string }[] = []

    // Collect all image URLs
    ;[...ASSETS.clothes, ...ASSETS.styles, ...ASSETS.accessories].forEach((asset) => {
      if (asset.image) {
        imagesToLoad.push({ id: asset.id, src: asset.image })
      }
    })

    // Load images
    const imagePromises = imagesToLoad.map(({ id, src }) => {
      return new Promise<{ id: string; img: HTMLImageElement }>((resolve, reject) => {
        const img = new Image()
        img.crossOrigin = "anonymous"
        img.onload = () => resolve({ id, img })
        img.onerror = reject
        img.src = src
      })
    })

    Promise.all(imagePromises)
      .then((results) => {
        const images: Record<string, HTMLImageElement> = {}
        results.forEach(({ id, img }) => {
          images[id] = img
        })
        setLoadedImages(images)
      })
      .catch((error) => {
        console.error("[v0] Failed to load images:", error)
      })
  }, [])

  useEffect(() => {
    const canvas = canvasRef.current
    if (!canvas) return

    const ctx = canvas.getContext("2d")
    if (!ctx) return

    // Clear canvas
    ctx.clearRect(0, 0, canvas.width, canvas.height)

    // Draw background
    const bg = ASSETS.backgrounds.find((b) => b.id === selectedBackground)
    if (bg && bg.type === "color") {
      ctx.fillStyle = bg.color
      ctx.fillRect(0, 0, canvas.width, canvas.height)
    }

    // Draw layers in order: clothes -> style -> accessories
    const layers = [
      ASSETS.clothes.find((c) => c.id === selectedClothes),
      ASSETS.styles.find((s) => s.id === selectedStyle),
      ASSETS.accessories.find((a) => a.id === selectedAccessory),
    ]

    layers.forEach((layer) => {
      if (layer && layer.image && loadedImages[layer.id]) {
        const img = loadedImages[layer.id]
        ctx.drawImage(img, 0, 0, canvas.width, canvas.height)
      }
    })
  }, [selectedBackground, selectedClothes, selectedStyle, selectedAccessory, loadedImages])

  // Download canvas as image
  const downloadImage = () => {
    const canvas = canvasRef.current
    if (!canvas) return

    const link = document.createElement("a")
    link.download = `pfp-${Date.now()}.png`
    link.href = canvas.toDataURL()
    link.click()
  }

  const renderAssetGrid = (assets: typeof ASSETS.clothes, selectedId: string, onSelect: (id: string) => void) => {
    return (
      <div className="grid grid-cols-3 gap-3">
        {assets.map((asset) => (
          <button
            key={asset.id}
            onClick={() => onSelect(asset.id)}
            className="group relative aspect-square overflow-hidden rounded-lg border-2 border-border bg-muted transition-all hover:border-primary"
            style={{
              borderColor: selectedId === asset.id ? "var(--primary)" : undefined,
            }}
          >
            {asset.image ? (
              <img src={asset.image || "/placeholder.svg"} alt={asset.name} className="h-full w-full object-cover" />
            ) : (
              <div className="flex h-full w-full items-center justify-center text-sm text-muted-foreground">None</div>
            )}
            {selectedId === asset.id && (
              <div className="absolute inset-0 flex items-center justify-center bg-black/20">
                <div className="flex h-10 w-10 items-center justify-center rounded-full bg-primary">
                  <Check className="h-6 w-6 text-primary-foreground" />
                </div>
              </div>
            )}
            <div className="absolute bottom-0 left-0 right-0 bg-black/60 px-2 py-1 text-center text-xs text-white">
              {asset.name}
            </div>
          </button>
        ))}
      </div>
    )
  }

  return (
    <div className="min-h-screen p-4 md:p-8">
      <div className="mx-auto max-w-7xl">
        {/* Header */}
        <div className="mb-8 flex items-start justify-between">
          <div>
            <h1 className="text-balance text-4xl font-bold text-foreground">PFP Generator</h1>
            <p className="mt-2 text-muted-foreground">Create your unique profile picture</p>
          </div>
          <Button
            variant="ghost"
            size="icon"
            onClick={() => setIsOpen(!isOpen)}
            className="text-muted-foreground hover:text-foreground"
          >
            <X className="h-6 w-6" />
          </Button>
        </div>

        {isOpen && (
          <div className="grid gap-6 lg:grid-cols-[1fr,1.5fr]">
            {/* Preview Section */}
            <div className="space-y-4">
              <Card className="border-2 border-primary bg-card p-6">
                <div className="relative aspect-square overflow-hidden rounded-lg border-4 border-primary bg-muted">
                  <canvas ref={canvasRef} width={400} height={400} className="h-full w-full" />
                </div>
              </Card>

              {/* Action Buttons */}
              <div className="grid grid-cols-2 gap-3">
                <Button onClick={randomizeAll} className="h-14 bg-primary text-primary-foreground hover:bg-primary/90">
                  <Shuffle className="mr-2 h-5 w-5" />
                  Randomize All
                </Button>
                <Button
                  onClick={downloadImage}
                  variant="outline"
                  className="h-14 border-2 border-primary bg-transparent text-primary hover:bg-primary hover:text-primary-foreground"
                >
                  <Download className="mr-2 h-5 w-5" />
                  Download
                </Button>
              </div>

              {/* Stats */}
              <Card className="border-border bg-card p-6">
                <div className="grid grid-cols-2 gap-4 text-center">
                  <div>
                    <div className="text-3xl font-bold text-primary">{totalCombinations.toLocaleString()}</div>
                    <div className="mt-1 text-sm text-muted-foreground">COMBINATIONS</div>
                  </div>
                  <div>
                    <div className="text-3xl font-bold text-primary">{totalAssets}</div>
                    <div className="mt-1 text-sm text-muted-foreground">TOTAL ASSETS</div>
                  </div>
                </div>
              </Card>
            </div>

            {/* Customization Section */}
            <Card className="border-border bg-card p-6">
              <Tabs defaultValue="background" className="w-full">
                <TabsList className="grid w-full grid-cols-4 bg-secondary">
                  <TabsTrigger
                    value="background"
                    className="data-[state=active]:bg-primary data-[state=active]:text-primary-foreground"
                  >
                    Background
                  </TabsTrigger>
                  <TabsTrigger
                    value="clothes"
                    className="data-[state=active]:bg-primary data-[state=active]:text-primary-foreground"
                  >
                    Clothes
                  </TabsTrigger>
                  <TabsTrigger
                    value="style"
                    className="data-[state=active]:bg-primary data-[state=active]:text-primary-foreground"
                  >
                    Style
                  </TabsTrigger>
                  <TabsTrigger
                    value="accessories"
                    className="data-[state=active]:bg-primary data-[state=active]:text-primary-foreground"
                  >
                    Head Accessories
                  </TabsTrigger>
                </TabsList>

                <TabsContent value="background" className="mt-6">
                  <div className="mb-4 flex items-center justify-between">
                    <h3 className="text-lg font-semibold text-foreground">Select Background</h3>
                    <span className="text-sm text-muted-foreground">{ASSETS.backgrounds.length} options</span>
                  </div>
                  <div className="grid grid-cols-3 gap-3">
                    {ASSETS.backgrounds.map((bg) => (
                      <button
                        key={bg.id}
                        onClick={() => setSelectedBackground(bg.id)}
                        className="group relative aspect-square overflow-hidden rounded-lg border-2 border-border transition-all hover:border-primary"
                        style={{
                          backgroundColor: bg.type === "color" ? bg.color : undefined,
                          borderColor: selectedBackground === bg.id ? "var(--primary)" : undefined,
                        }}
                      >
                        {selectedBackground === bg.id && (
                          <div className="absolute inset-0 flex items-center justify-center bg-black/20">
                            <div className="flex h-10 w-10 items-center justify-center rounded-full bg-primary">
                              <Check className="h-6 w-6 text-primary-foreground" />
                            </div>
                          </div>
                        )}
                        <div className="absolute bottom-0 left-0 right-0 bg-black/60 px-2 py-1 text-center text-xs text-white">
                          {bg.name}
                        </div>
                      </button>
                    ))}
                  </div>
                </TabsContent>

                <TabsContent value="clothes" className="mt-6">
                  <div className="mb-4 flex items-center justify-between">
                    <h3 className="text-lg font-semibold text-foreground">Select Clothes</h3>
                    <span className="text-sm text-muted-foreground">{ASSETS.clothes.length} options</span>
                  </div>
                  {renderAssetGrid(ASSETS.clothes, selectedClothes, setSelectedClothes)}
                </TabsContent>

                <TabsContent value="style" className="mt-6">
                  <div className="mb-4 flex items-center justify-between">
                    <h3 className="text-lg font-semibold text-foreground">Select Style</h3>
                    <span className="text-sm text-muted-foreground">{ASSETS.styles.length} options</span>
                  </div>
                  {renderAssetGrid(ASSETS.styles, selectedStyle, setSelectedStyle)}
                </TabsContent>

                <TabsContent value="accessories" className="mt-6">
                  <div className="mb-4 flex items-center justify-between">
                    <h3 className="text-lg font-semibold text-foreground">Select Head Accessories</h3>
                    <span className="text-sm text-muted-foreground">{ASSETS.accessories.length} options</span>
                  </div>
                  {renderAssetGrid(ASSETS.accessories, selectedAccessory, setSelectedAccessory)}
                </TabsContent>
              </Tabs>
            </Card>
          </div>
        )}
      </div>
    </div>
  )
}
